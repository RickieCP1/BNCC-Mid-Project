const form = document.getElementById('position');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!name) {
        document.getElementById('name').classList.add('invalid');
    } else {
        document.getElementById('name').classList.remove('invalid');
    }

    if (!email || !validateEmail(email)) {
        document.getElementById('email').classList.add('invalid');
    } else {
        document.getElementById('email').classList.remove('invalid');
    }

    if (!password) {
        document.getElementById('password').classList.add('invalid');
    } else {
        document.getElementById('password').classList.remove('invalid');
    }

    if (name && email && password) {
        form.submit();
    }
});

// Function to validate email address
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

