function myFunction() {
    var element = document.body;
    element.classList.toggle("dark-mode");
  }
