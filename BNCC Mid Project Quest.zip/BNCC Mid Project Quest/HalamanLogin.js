const form = document.getElementById('form');

form.addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();


    if (!email || !validateEmail(email)) {
        document.getElementById('email').classList.add('invalid');
    } else {
        document.getElementById('email').classList.remove('invalid');
    }

    if (!password) {
        document.getElementById('password').classList.add('invalid');
    } else {
        document.getElementById('password').classList.remove('invalid');
    }

    if (email && password) {
        form.submit();
    }
});

// Function to validate email address
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}


